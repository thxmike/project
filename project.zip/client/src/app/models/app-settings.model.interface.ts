export interface AppSettings {
  production: boolean;
  user_file_api: {
    uri: string;
  };
}
